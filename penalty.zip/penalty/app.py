from auth import login
from admin import *
from employee import start_work


def show_auth_menu():
    print("""
    1. Login
    2. Exit
    """)
    choice = input("Enter your choice: ")
    if choice == "1":
        result = login()
        if result == "admin":
            return show_admin_menu()
        elif result == "employee":
            return show_employee_menu()
        else:
            print("Invalid phone or password")
            return show_auth_menu()
    elif choice == "2":
        print("Good bye")
    else:
        print("Invalid choice")
        show_auth_menu()


def show_admin_menu():
    print("""
    1. Add new employee
    2. Show all employees
    3. Delete employee
    4. Show all penalties
    5. Logout
    """)

    choice = input("Enter your choice: ")
    if choice == "1":
        if not add_employee():
            print("Employee does not added")

    elif choice == "2":
        if not show_all_employees():
            print("Employee does not added")

    elif choice == "3":
        if not delete_employee():
            print("Employee does not added")

    elif choice == "4":
        if not show_all_penalties():
            print("Employee does not added")

    elif choice == "5":
        return show_auth_menu()
    return show_admin_menu()


def show_employee_menu():
    print("""
    1. Start work
    2. Show all my penalties
    3. Logout
    """)

    choice = input("Enter your choice: ")
    if choice == "1":
        result = start_work()
        if result:
            print(f"You late to work: {result}")
    elif choice == "2":
        pass
    elif choice == "3":
        return show_auth_menu()


if __name__ == "__main__":
    from file_manager import employee_manager

    employee_manager.write_headers(headers=['full_name', 'phone', 'password', 'start_time', 'penalty', 'is_active'])
    show_auth_menu()
