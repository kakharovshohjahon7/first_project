from leson-7.penalty.file_manager import employee_manager

admin_phone = 'admin'
admin_password = 'admin'

current_employee = None


def check_employee(phone, password):
    employees = employee_manager.read()
    for employee in employees:
        if employee[1] == phone and employee [2] == password:
            updete_
            return "employee"
    return False


def login():
    phone = input("Enter your phone number: ")
    password = input("Enter your password: ")
    if phone == admin_phone and password == password:
        return "admin"
    elif check_employee(phone, password):
        if phone == admin_phone:
            check_employee == True
            return "employee"
    return False

