from file_manager import employee_manager
from auth import current_employee
from datetime import datetime


class Employee:
    def __init__(self, full_name, phone_number, password, start_time, is_active):
        self.full_name = full_name
        self.phone_number = phone_number
        self.password = password
        self.start_time = start_time
        self.__penalty = 0
        self.__is_active = False

    def get_as_list(self):
        return [self.full_name, self.phone_number, self.password, self.start_time, self.__penalty, self.__is_active]


def update_penalty():
    employees = employee_manager.read()
    rows = []
    for employee in employees:
        if employee[1] == current_employee[1]:
            rows.append(current_employee)
        else:
            rows.append(employee)
    employee_manager.write(data=rows)


def start_work():
    current_time = datetime.now().time()
    current_employee_time = datetime.strptime(current_employee[3], '%H:%M:%S').time()
    if current_time > current_employee_time:
        minute = current_time.minute - current_employee_time.minute
        current_employee[4] += minute * 1000
        update_penalty()
        return minute

    return True

def log_out():
    index = 1
    if employee_manager[1] > 