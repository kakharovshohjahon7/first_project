from employee import Employee
from file_manager import employee_manager


def add_employee():
    try:
        full_name = input('Enter your full name: ')
        phone = input('Enter your phone number: ')
        password = input('Enter your password: ')
        start_time = input('Enter start time: ')

        employee = Employee(full_name, phone, password, start_time)
        employee_manager.append(row=employee.get_as_list())
        return True
    except Exception as e:
        print(e)
        return False


def show_all_employees():
    all_employees = employee_manager.read()
    for employee in all_employees:
        print(f"{employee[0]}\t{employee[1]}\t{employee[2]}\t{employee[3]}\t{employee[4]}")
    return True


def delete_employee():
    phone = input('Enter your phone number: ')
    rows = []
    all_employees = employee_manager.read()
    for employee in all_employees:
        if employee[1] != phone:
            rows.append(employee)
    employee_manager.write(data=rows)
    return True



def show_all_penalties():
    pass
